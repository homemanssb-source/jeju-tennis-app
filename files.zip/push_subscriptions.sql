-- Supabase SQL Editor에서 실행
-- push_subscriptions 테이블 생성

create table if not exists push_subscriptions (
  id          uuid primary key default gen_random_uuid(),
  endpoint    text unique not null,
  p256dh      text not null,
  auth        text not null,
  created_at  timestamptz default now()
);

-- RLS 활성화
alter table push_subscriptions enable row level security;

-- 누구나 구독 등록/삭제 가능 (anon key로 Edge Function 호출)
-- 단, Edge Function은 service_role key를 사용하므로 RLS 우회
-- 아래 정책은 직접 테이블 접근을 막는 용도
create policy "service role only"
  on push_subscriptions
  for all
  using (false);  -- anon 직접 접근 차단, Edge Function(service role)만 허용
